{
  "arabica": [
    {
      "foto": "images/produk/product_capuchino.jpg",
      "nama": "Cappuccino Arabica",
      "size": "500 Gram",
      "harga": "200.000",
      "link": "https://www.google.com/search?q=cappuccino+arabica&tbm=shop"
    },
    {
      "foto": "images/produk/product_espresso.jpg",
      "nama": "Pahit Arabica",
      "size": "100 Gram",
      "harga": "100.000",
      "link": "https://www.google.com/search?q=pahit+arabica&tbm=shop"
    },
    {
      "foto": "images/produk/product_latte.jpg",
      "nama": "Latte Arabica",
      "size": "150 Gram",
      "harga": "150.000",
      "link": "https://www.google.com/search?q=latte+arabica&tbm=shop"
    }
  ]
  <option value="nama-kategori"> di <select id="select_kopi">
  "robusta": [
    {
      "foto": "images/produk/product_kopi_susu.jpg",
      "nama": "Kopsus Robusta",
      "size": "100 Gram",
      "harga": "80.000",
      "link": "https://www.google.com/search?q=kopi+susu+robusta&tbm=shop"
    },
    {
      "foto": "images/produk/product_latte.jpg",
      "nama": "Latte Robusta",
      "size": "150 Gram",
      "harga": "150.000",
      "link": "https://www.google.com/search?q=latte+robusta&tbm=shop"
    }
  ],
  "nonkopi": [
    {
      "foto": "https://img.freepik.com/free-photo/top-view-set-ice-cream-cones-with-chocolate_23-2148425392.jpg",
      "nama": "Ice Cream",
      "size": "100 Gram",
      "harga": "10.000",
      "link": "https://www.google.com/search?q=ice+cream+cone&tbm=shop"
    }
  ]
}{
  "arabica": [
    {
      "foto": "images/produk/product_capuchino.jpg",
      "nama": "Cappuccino Arabica",
      "size": "500 Gram",
      "harga": "200.000",
      "link": "https://www.google.com/search?q=cappuccino+arabica&tbm=shop"
    },
    {
      "foto": "images/produk/product_espresso.jpg",
      "nama": "Pahit Arabica",
      "size": "100 Gram",
      "harga": "100.000",
      "link": "https://www.google.com/search?q=pahit+arabica&tbm=shop"
    },
    {
      "foto": "images/produk/product_latte.jpg",
      "nama": "Latte Arabica",
      "size": "150 Gram",
      "harga": "150.000",
      "link": "https://www.google.com/search?q=latte+arabica&tbm=shop"
    }
  ],
  "robusta": [
    {
      "foto": "images/produk/product_kopi_susu.jpg",
      "nama": "Kopsus Robusta",
      "size": "100 Gram",
      "harga": "80.000",
      "link": "https://www.google.com/search?q=kopi+susu+robusta&tbm=shop"
    },
    {
      "foto": "images/produk/product_latte.jpg",
      "nama": "Latte Robusta",
      "size": "150 Gram",
      "harga": "150.000",
      "link": "http